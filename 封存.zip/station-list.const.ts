export const stationList = [
    {
      'Station': '三重國小站',
      'Destination': '南勢角站',
      'UpdateTime': '2018-10-15T22:14:41.557'
    },
    /*
     * 太長了，中間省略。
     */
    {
      'Station': '麟光站',
      'Destination': '南港展覽館站',
      'UpdateTime': '2018-10-15T22:14:41'
    }
  ];